/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 16:37:22 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:15:51 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void		ra(t_frame *stacks)
{
	if (stacks->a && stacks->a->next)
	{
		stacks->a = stacks->a->next;
		add_list(stacks, RA);
	}
}

void		rb(t_frame *stacks)
{
	if (stacks->b && stacks->b->next)
	{
		stacks->b = stacks->b->next;
		add_list(stacks, RB);
	}
}

void		rr(t_frame *stacks)
{
	ra(stacks);
	rb(stacks);
}
