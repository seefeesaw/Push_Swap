/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_clist.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 16:22:07 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:13:34 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

/*
** Create a list fill it with data
*/

t_clist	*create_clist(int data, t_frame *stacks)
{
	t_clist	*head;

	if (!(head = (t_clist*)malloc(sizeof(*head))))
		error_exit(stacks);
	if (head)
	{
		head->prev = head;
		head->next = head;
		head->data = data;
	}
	return (head);
}

/*
** Create a list fill it with data on top
*/

void	add_to_top(t_clist **head, int data, t_frame *stacks)
{
	t_clist *new;

	if (!(new = (t_clist*)malloc(sizeof(*new))))
		error_exit(stacks);
	new->data = data;
	new->next = *head;
	new->prev = (*head)->prev;
	(*head)->prev->next = new;
	(*head)->prev = new;
	*head = new;
}

/*
** Create a list fill it with dat at the bottom
*/

void	add_to_tail(t_clist *head, int data, t_frame *stacks)
{
	t_clist *new;

	if (!(new = (t_clist*)malloc(sizeof(*new))))
		error_exit(stacks);
	new->data = data;
	new->next = head;
	new->prev = (head->next == head) ? head : head->prev;
	head->prev = new;
	new->prev->next = new;
}
