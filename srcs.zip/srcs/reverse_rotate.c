/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   reverse_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 16:36:56 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:15:43 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void		rra(t_frame *stacks)
{
	if (stacks->a && stacks->a->prev)
	{
		stacks->a = stacks->a->prev;
		add_list(stacks, RRA);
	}
}

void		rrb(t_frame *stacks)
{
	if (stacks->b && stacks->b->prev)
	{
		stacks->b = stacks->b->prev;
		add_list(stacks, RRB);
	}
}

void		rrr(t_frame *stacks)
{
	rra(stacks);
	rrb(stacks);
}
