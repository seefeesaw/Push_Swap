/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   remove_clist.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 16:35:24 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:15:36 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

void	remove_element(t_clist **head, t_clist *element)
{
	if ((*head)->next == *head)
	{
		free(*head);
		*head = NULL;
	}
	else
	{
		element->prev->next = element->next;
		element->next->prev = element->prev;
		free(element);
	}
}

void	remove_head(t_clist **head)
{
	t_clist	*tmp;

	if (!(*head))
		return ;
	tmp = (*head)->next;
	if ((*head)->next == *head)
	{
		free(*head);
		*head = NULL;
	}
	else
	{
		(*head)->prev->next = (*head)->next;
		(*head)->next->prev = (*head)->prev;
		free(*head);
		*head = tmp;
	}
}
