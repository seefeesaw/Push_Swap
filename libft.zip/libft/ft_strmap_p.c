/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap_p.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:47:50 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:47:53 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

/*
** Same as ft_strmap, but overwrites the input string with the modified one.
*/

char	*ft_strmap_p(char *s, char (*f)(char))
{
	int		i;

	i = 0;
	if (!s || !f)
		return (NULL);
	while (s[i] != '\0')
	{
		s[i] = f(s[i]);
		i++;
	}
	return (s);
}
