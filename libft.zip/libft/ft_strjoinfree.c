/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoinfree.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:43:01 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:43:04 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void		free_str(char *s1, char *s2, int del)
{
	if (del == 1)
		free(s1);
	else if (del == 2)
		free(s2);
	else
	{
		free(s1);
		free(s2);
	}
}

char			*ft_strjoinfree(char *s1, char *s2, int del)
{
	char	*new;
	int		i;
	int		len1;
	int		len;

	if (s1 == NULL || s2 == NULL)
		return (NULL);
	len1 = ft_strlen(s1);
	len = len1 + ft_strlen(s2);
	if (!(new = ft_strnew(len)))
		return (NULL);
	i = 0;
	while (i < len)
	{
		if (i < len1)
			new[i] = s1[i];
		if (i < (len - len1))
			new[i + len1] = s2[i];
		i++;
	}
	free_str(s1, s2, del);
	return (new);
}
