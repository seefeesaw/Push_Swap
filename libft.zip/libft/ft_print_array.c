/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_array.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:46:05 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:46:08 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_print_array(const char **arr)
{
	int i;
	int j;

	i = 0;
	if (arr)
	{
		while (arr[i] != '\0')
		{
			j = 0;
			while (arr[i][j] != '\0')
			{
				ft_putchar(arr[i][j]);
				j++;
			}
			ft_putchar('\n');
			i++;
		}
	}
}
