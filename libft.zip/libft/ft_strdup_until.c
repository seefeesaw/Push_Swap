/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup_until.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:48:47 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:48:49 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char		*ft_strdup_until(const char *s, const char *end)
{
	size_t		i;
	char		*new;

	i = 0;
	while (s[i] && &s[i] != end)
		i++;
	new = ft_strnew(i);
	i = 0;
	while (s[i] && &s[i] != end)
	{
		new[i] = s[i];
		i++;
	}
	return (new);
}
