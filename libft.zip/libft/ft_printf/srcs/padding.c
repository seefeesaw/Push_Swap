/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   padding.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:15:53 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:18:20 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static char	*handle_precision(char *str, t_printf *specs)
{
	char	*tmp;
	int		diff;
	char	fill;

	if (specs->precision == 0)
		return (ft_strdup(""));
	diff = specs->precision - ft_strlen(str);
	if ((specs->isplus || specs->negative) && specs->negative)
		specs->isplus = 0;
	tmp = ft_strnew(diff);
	fill = (specs->iszero ||
			ft_strchr(SPECIFIERS, specs->converter)) ? '0' : ' ';
	tmp = ft_memset((void*)tmp, fill, diff);
	return (ft_strjoinfree(tmp, str, 3));
}

static char	*handle_width(char *str, t_printf *specs)
{
	char	*tmp;
	char	fill;
	int		diff;

	diff = specs->width - ft_strlen(str);
	fill = (specs->iszero == 1 && !specs->isminus) ? '0' : ' ';
	diff -= (specs->negative || specs->isplus) ? 1 : 0;
	tmp = ft_strnew(diff);
	tmp = ft_memset((void*)tmp, fill, diff);
	if (specs->isminus)
		return (ft_strjoinfree(str, tmp, 3));
	else
		return (ft_strjoinfree(tmp, str, 3));
}

static char	*add_sign(char *str, t_printf *specs)
{
	char	sign;
	int		i;

	i = 0;
	if (specs->converter == 'c' || specs->converter == 'C')
		return (str);
	sign = (specs->negative) ? '-' : '+';
	if (specs->negative || specs->isplus)
		str = ft_strjoinfree(" ", str, 2);
	while (str[i + 1] == ' ')
		i++;
	str[i] = sign;
	return (str);
}

char		*padding(char *str, t_printf *specs)
{
	if (!str)
		return (NULL);
	if (specs->precision > 0 && specs->precision > (int)ft_strlen(str))
		str = handle_precision(str, specs);
	if (specs->width > 0 && specs->width > (int)ft_strlen(str))
		str = handle_width(str, specs);
	if (specs->isplus || specs->negative)
		str = add_sign(str, specs);
	if (specs->precision > 0 && specs->width > 0 &&
			specs->width > specs->precision &&
			(int)ft_strlen(str) > specs->width && specs->isminus)
		str[(int)ft_strlen(str) - 1] = '\0';
	return (str);
}
