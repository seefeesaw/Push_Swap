/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrev.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/08 17:44:32 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/08 17:44:35 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrev(const char *s)
{
	int		len;
	int		i;
	char	*rev;

	len = ft_strlen(s);
	if (!(rev = (char*)malloc(sizeof(*rev) * len + 1)) || !s)
		return (NULL);
	i = 0;
	len--;
	while (s[i])
	{
		rev[i] = s[len];
		i++;
		len--;
	}
	rev[i] = '\0';
	return (rev);
}
