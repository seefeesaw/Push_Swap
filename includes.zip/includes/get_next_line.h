/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ashongwe <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/09 08:46:37 by ashongwe          #+#    #+#             */
/*   Updated: 2019/08/09 09:12:12 by ashongwe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef GET_NEXT_LINE_H
# define GET_NEXT_LINE_H

# define BUFF_SIZE 100
# define FD_ELEM ((t_fd*)current->content)
# include <unistd.h>
# include "./libft.h"

typedef	struct	s_fd
{
	int		fide;
	char	*rest;
}				t_fd;

int				get_next_line(const int fd, char **line);

#endif
